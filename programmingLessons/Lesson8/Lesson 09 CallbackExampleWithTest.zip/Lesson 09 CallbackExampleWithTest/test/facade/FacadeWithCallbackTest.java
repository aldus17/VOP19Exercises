/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author fsan
 */
public class FacadeWithCallbackTest {

    FacadeWithCallback facade;
    CallBackInterface soutCallBack;
    Dice dice;
    
    public FacadeWithCallbackTest() {
    }

    @BeforeClass
    public static void setUpClass() {

    }

    @AfterClass
    public static void tearDownClass() {

    }

    @Before
    public void setUp() {
//        TODO
//        Instantiate your CallBackInterface
//        Instantiate and start your Facade Thread
    }

    @After
    public void tearDown() {
//        TODO
//        Interrupt your facade Thread
    }

    /**
     * Test of run method, of class FacadeWithCallback.
     */
    
    @Test
    public void testRun() {
//        TODO
//        Test the run() method
//        Assert if the dice.getDie1() and dice.getDie2() are equal to integer 6
    }

}
